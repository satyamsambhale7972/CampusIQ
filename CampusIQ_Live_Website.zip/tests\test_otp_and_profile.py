"""
Mobile OTP Verification and Profile Management Tests
"""
import pytest
from starlette.testclient import TestClient

from main import app
from auth import create_access_token
from database import db

client = TestClient(app)

def test_mobile_otp_lifecycle():
    """Verify full mobile OTP flow: send OTP, cooldown enforcement, incorrect OTP rejection, and successful verification."""
    token = create_access_token(user_id="student-otp-test", email="otp_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}
    phone = "9876543210"
    country = "+91"

    # 1. Request OTP
    send_resp = client.post("/api/auth/otp/send", headers=headers, json={"phone_number": phone, "country_code": country})
    assert send_resp.status_code == 200
    data = send_resp.json()
    assert data["success"] is True
    dev_otp = data.get("dev_otp")
    assert dev_otp is not None, "Dev OTP should be provided in test environment"

    # 2. Attempt immediate second OTP (cooldown check)
    cooldown_resp = client.post("/api/auth/otp/send", headers=headers, json={"phone_number": phone, "country_code": country})
    assert cooldown_resp.status_code == 429
    assert "wait" in cooldown_resp.json()["detail"].lower()

    # 3. Verify with wrong code
    bad_verify = client.post("/api/auth/otp/verify", headers=headers, json={"phone_number": phone, "country_code": country, "otp": "000000"})
    assert bad_verify.status_code == 400
    assert "Incorrect OTP" in bad_verify.json()["detail"]

    # 4. Verify with correct code
    good_verify = client.post("/api/auth/otp/verify", headers=headers, json={"phone_number": phone, "country_code": country, "otp": dev_otp})
    assert good_verify.status_code == 200
    assert "successfully verified" in good_verify.json()["message"]

    # 5. Check profile reflects verified phone
    prof_resp = client.get("/api/profile", headers=headers)
    assert prof_resp.status_code == 200
    prof = prof_resp.json()
    assert prof["phone_number"] == phone
    assert prof["phone_verified"] is True

def test_profile_update_and_photo():
    """Test updating student name, department, semester, and photo."""
    token = create_access_token(user_id="student-profile-test", email="profile_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    update_resp = client.put(
        "/api/profile",
        headers=headers,
        json={
            "full_name": "Satyam Sambhale",
            "department": "Artificial Intelligence & Data Science",
            "year_semester": "Year 3, Semester 6",
            "branch": "AI & DS"
        }
    )
    assert update_resp.status_code == 200
    profile = update_resp.json()["profile"]
    assert profile["full_name"] == "Satyam Sambhale"
    assert profile["department"] == "Artificial Intelligence & Data Science"

    # Photo update
    photo_resp = client.post(
        "/api/profile/photo",
        headers=headers,
        json={"avatar_url": "https://campusiq.internal/avatars/satyam.png"}
    )
    assert photo_resp.status_code == 200

def test_student_account_purge():
    """Verify permanent student account deletion."""
    token = create_access_token(user_id="student-purge-test", email="purge_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    del_resp = client.delete("/api/profile/account", headers=headers)
    assert del_resp.status_code == 200
    assert "purged" in del_resp.json()["message"].lower()

    # Re-accessing with that token should fail or create empty profile
    check = client.get("/api/profile", headers=headers)
    # The profile row was deleted; auto-create recreates empty
    assert check.status_code == 200
    assert check.json()["full_name"] != "Satyam Sambhale"
