"""
CampusIQ — Vercel Serverless Function Entrypoint
Exposes the FastAPI ASGI application for the Vercel Python runtime (@vercel/python).
Handles all /api/* routes seamlessly with zero-downtime serverless execution.
"""
import os
import sys
from pathlib import Path

# Add project root directory to sys.path so modules (config, database, main, auth, etc.) resolve cleanly
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Ensure VERCEL environment flag is active for serverless /tmp storage adapter
os.environ["VERCEL"] = "1"

# Import production FastAPI application
from main import app

# Vercel requires WSGI/ASGI 'app' or 'handler'
handler = app
