"""
Tests for CampusIQ Vercel Serverless Function & Database Session Persistence
Verifies:
1. api/index.py Vercel entrypoint loads cleanly.
2. User signup stores salted password hash in user_credentials table.
3. User signin authenticates against database credentials and creates active session in auth_sessions.
4. User signout updates auth_sessions to status='revoked' and records SIGN_OUT in audit_logs.
5. Revoked session tokens are rejected on protected endpoints.
6. /api/auth/sessions returns persistent session history from the database.
"""
import pytest
from starlette.testclient import TestClient
from main import app
from database import db
import uuid
import api.index as vercel_entrypoint

client = TestClient(app)

@pytest.fixture(autouse=True)
def cleanup_test_accounts():
    """Ensure test student accounts are clean before and after each test run."""
    conn = db.get_connection()
    try:
        with conn:
            conn.execute("DELETE FROM user_credentials WHERE email LIKE 'student.%@campusiq.edu'")
            conn.execute("DELETE FROM auth_sessions WHERE email LIKE 'student.%@campusiq.edu'")
            conn.execute("DELETE FROM audit_logs WHERE actor_email LIKE 'student.%@campusiq.edu'")
            conn.execute("DELETE FROM profiles WHERE email LIKE 'student.%@campusiq.edu'")
    finally:
        conn.close()
    yield

def test_vercel_serverless_entrypoint():
    """Verify that api/index.py exposes ASGI app and handler for Vercel Python runtime."""
    assert hasattr(vercel_entrypoint, "app")
    assert hasattr(vercel_entrypoint, "handler")
    assert vercel_entrypoint.app is app

def test_signup_persists_credentials_and_session_in_database():
    """Verify signup saves hashed credentials in user_credentials and active session in auth_sessions."""
    test_email = "student.vercel@campusiq.edu"
    test_password = "SecurePassword123!"

    resp = client.post("/api/auth/signup", json={
        "email": test_email,
        "password": test_password,
        "full_name": "Vercel Test Student"
    })
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert data["success"] is True
    assert "access_token" in data
    token = data["access_token"]

    # 1. Verify credentials table in database
    conn = db.get_connection()
    try:
        cred = conn.execute("SELECT * FROM user_credentials WHERE email = ?", (test_email,)).fetchone()
        assert cred is not None
        assert cred["password_hash"] != test_password
        assert cred["password_salt"] is not None

        # Verify cryptographic verification helper
        assert db.verify_user_credentials(test_email, test_password) is not None
        assert db.verify_user_credentials(test_email, "WrongPassword") is None

        # 2. Verify active session in auth_sessions table
        active_session = db.get_active_session(token)
        assert active_session is not None
        assert active_session["email"] == test_email
        assert active_session["status"] == "active"
        assert active_session["signed_out_at"] is None

        # 3. Verify SIGN_IN event in audit_logs
        log = conn.execute(
            "SELECT * FROM audit_logs WHERE actor_email = ? AND action = 'SIGN_IN' ORDER BY created_at DESC LIMIT 1",
            (test_email,)
        ).fetchone()
        assert log is not None
        assert log["target_entity"] == "auth_sessions"
    finally:
        conn.close()

def test_signin_verifies_credentials_and_registers_session():
    """Verify signin verifies password and creates active session."""
    test_email = "student.signin@campusiq.edu"
    test_password = "CorrectPassword789!"

    # Sign up first
    client.post("/api/auth/signup", json={
        "email": test_email,
        "password": test_password,
        "full_name": "Sign In Student"
    })

    # Unregistered email attempt must fail with 401
    unreg_resp = client.post("/api/auth/signin", json={
        "email": "unregistered.fake.student@campusiq.edu",
        "password": "Password123!"
    })
    assert unreg_resp.status_code == 401
    assert "Account not found" in unreg_resp.json()["detail"]

    # Wrong password attempt must fail with 401
    bad_resp = client.post("/api/auth/signin", json={
        "email": test_email,
        "password": "WrongPassword999!"
    })
    assert bad_resp.status_code == 401
    assert "Incorrect password" in bad_resp.json()["detail"]

    # Duplicate signup with existing email must fail with 400
    dup_resp = client.post("/api/auth/signup", json={
        "email": test_email,
        "password": "NewPassword123!",
        "full_name": "Duplicate Student"
    })
    assert dup_resp.status_code == 400
    assert "already exists" in dup_resp.json()["detail"]

    # Correct password succeeds and issues active session
    good_resp = client.post("/api/auth/signin", json={
        "email": test_email,
        "password": test_password
    })
    assert good_resp.status_code == 200
    token = good_resp.json()["access_token"]

    # Verify session is active in database
    session = db.get_active_session(token)
    assert session is not None
    assert session["status"] == "active"

def test_signout_revokes_database_session_and_blocks_token():
    """Verify signout marks session revoked and subsequent requests with the token are rejected."""
    test_email = "student.signout@campusiq.edu"
    test_password = "SignoutPassword456!"

    # Sign in
    resp = client.post("/api/auth/signup", json={
        "email": test_email,
        "password": test_password,
        "full_name": "Sign Out Student"
    })
    token = resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Verify token works on protected profile endpoint
    profile_resp = client.get("/api/profile", headers=headers)
    assert profile_resp.status_code == 200

    # Call signout endpoint
    signout_resp = client.post("/api/auth/signout", headers=headers)
    assert signout_resp.status_code == 200
    assert signout_resp.json()["success"] is True

    # 1. Database session status must be 'revoked'
    session_rec = db.get_session_by_token(token)
    assert session_rec is not None
    assert session_rec["status"] == "revoked"
    assert session_rec["signed_out_at"] is not None

    # 2. Active session lookup must return None
    assert db.get_active_session(token) is None

    # 3. SIGN_OUT audit log must be recorded in database
    conn = db.get_connection()
    try:
        log = conn.execute(
            "SELECT * FROM audit_logs WHERE actor_email = ? AND action = 'SIGN_OUT' ORDER BY created_at DESC LIMIT 1",
            (test_email,)
        ).fetchone()
        assert log is not None
    finally:
        conn.close()

    # 4. Subsequent authenticated API calls with revoked token must fail with 401
    revoked_call = client.get("/api/profile", headers=headers)
    assert revoked_call.status_code == 401
    assert "signed out" in revoked_call.json()["detail"].lower()

def test_list_user_sessions_endpoint():
    """Verify /api/auth/sessions returns list of user's sessions."""
    test_email = "student.sessions@campusiq.edu"
    test_password = "SessionsPassword123!"

    resp = client.post("/api/auth/signup", json={
        "email": test_email,
        "password": test_password,
        "full_name": "Sessions Student"
    })
    token = resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    sessions_resp = client.get("/api/auth/sessions", headers=headers)
    assert sessions_resp.status_code == 200
    data = sessions_resp.json()
    assert data["email"] == test_email
    assert data["count"] >= 1
    assert len(data["sessions"]) >= 1
    assert data["sessions"][0]["status"] == "active"

def test_real_database_authentication_workflow():
    """
    Verifies the complete real database auth workflow:
    1. Random/wrong email cannot sign in (returns 401).
    2. Wrong password returns 401.
    3. Sign up registers real account in database.
    4. Duplicate sign up is rejected (returns 400).
    5. Sign in with real registered account succeeds (returns 200).
    6. Baseline seeded accounts authenticate properly.
    """
    fake_email = "nonexistent.student.999@campusiq.edu"
    resp_fake = client.post("/api/auth/signin", json={
        "email": fake_email,
        "password": "Password123!"
    })
    assert resp_fake.status_code == 401
    assert "Account not found" in resp_fake.json()["detail"]

    real_email = "student.realworkflow@campusiq.edu"
    real_pwd = "MyRealPassword2026!"

    # Sign up real account
    signup_resp = client.post("/api/auth/signup", json={
        "email": real_email,
        "password": real_pwd,
        "full_name": "Real Workflow Student"
    })
    assert signup_resp.status_code == 200
    assert signup_resp.json()["user"]["email"] == real_email

    # Duplicate signup rejected
    dup_resp = client.post("/api/auth/signup", json={
        "email": real_email,
        "password": real_pwd,
        "full_name": "Real Workflow Student"
    })
    assert dup_resp.status_code == 400

    # Wrong password sign in rejected
    wrong_resp = client.post("/api/auth/signin", json={
        "email": real_email,
        "password": "WrongPassword"
    })
    assert wrong_resp.status_code == 401
    assert "Incorrect password" in wrong_resp.json()["detail"]

    # Real sign in succeeds
    login_resp = client.post("/api/auth/signin", json={
        "email": real_email,
        "password": real_pwd
    })
    assert login_resp.status_code == 200
    assert login_resp.json()["user"]["email"] == real_email
    assert "access_token" in login_resp.json()

