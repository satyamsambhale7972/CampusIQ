"""
Pytest configuration and global fixtures for CampusIQ test suite.
"""
import pytest
from main import rate_limiter

@pytest.fixture(autouse=True)
def reset_rate_limiter():
    """Reset in-memory rate limiter between test cases to prevent cross-test throttling."""
    rate_limiter.requests.clear()
    yield
    rate_limiter.requests.clear()
