"""
CampusIQ 2.0 — Automated Test Suite for Distinctive Platform Features
Tests:
- Unified 12-Section Dashboard Summary
- Student Success Radar (multi-dimensional academic telemetry)
- AI Study Planner (session creation, status updates, deletion)
- Skill & Career Roadmap (goals, checklist milestones, completion metrics)
- Campus Navigator Directory (search, category filtering, emergency flags)
- Campus Notice Intelligence (priority filtering, saved bookmarks, read tracking)
- Persistent Recent User Activity Log
"""
import pytest
from starlette.testclient import TestClient
from main import app
from auth import create_access_token
from database import db

client = TestClient(app)

@pytest.fixture
def auth_headers():
    db.init_db()
    user = db.get_or_create_profile(
        user_id="test-student-unique-101",
        email="student@campusiq.edu",
        full_name="Test Student",
        role="student"
    )
    token = create_access_token(user["id"], user["email"], user["role"])
    return {"Authorization": f"Bearer {token}"}

def test_dashboard_summary_12_sections(auth_headers):
    """Verify single-roundtrip 12-section cockpit payload."""
    res = client.get("/api/dashboard/summary", headers=auth_headers)
    assert res.status_code == 200
    data = res.json()
    assert "student_profile" in data
    assert "today_classes" in data
    assert "academic_performance" in data
    assert "attendance_velocity" in data
    assert "deadlines_countdown" in data
    assert "assignment_progress" in data
    assert "verified_notices" in data
    assert "ai_study_suggestions" in data
    assert "open_tickets" in data
    assert "recent_activities" in data
    assert "facilities_occupancy" in data

    # Validate attendance velocity and buffer
    att = data["attendance_velocity"]
    assert "overall_rate" in att
    assert "buffer_classes_remaining" in att

def test_student_success_radar(auth_headers):
    """Verify success radar scores, strengths, weaknesses, velocity, and rationale."""
    res = client.get("/api/radar", headers=auth_headers)
    assert res.status_code == 200
    data = res.json()
    assert "overall_score" in data
    assert "academic_health" in data
    assert "subject_strengths" in data
    assert "subject_weaknesses" in data
    assert "recommended_actions" in data
    assert "calculation_rationale" in data

    # Check that recommendation distinguishes facts from advice
    assert len(data["recommended_actions"]) > 0
    rec = data["recommended_actions"][0]
    assert "action" in rec
    assert "reason" in rec

def test_study_planner_lifecycle(auth_headers):
    """Verify study timetable creation, toggle, and deletion."""
    # 1. Fetch active timetable
    res = client.get("/api/study-planner", headers=auth_headers)
    assert res.status_code == 200
    initial_data = res.json()
    initial_count = initial_data.get("total_sessions", 0)

    # 2. Add a new study session
    session_payload = {
        "subject_name": "Compiler Design",
        "topic": "LL(1) Syntax Analysis",
        "session_date": "2026-10-25",
        "start_time": "17:00",
        "duration_minutes": 45
    }
    create_res = client.post("/api/study-planner/session", headers=auth_headers, json=session_payload)
    assert create_res.status_code == 200
    session_id = create_res.json()["session_id"]
    assert session_id is not None

    # 3. Toggle status to completed
    patch_res = client.patch(
        f"/api/study-planner/session/{session_id}",
        headers=auth_headers,
        json={"status": "completed"}
    )
    assert patch_res.status_code == 200
    assert patch_res.json()["status"] == "completed"

    # 4. Delete the session
    del_res = client.delete(f"/api/study-planner/session/{session_id}", headers=auth_headers)
    assert del_res.status_code == 200
    assert del_res.json()["success"] is True

def test_career_roadmap_milestones_and_completion(auth_headers):
    """Verify career goal creation, milestone progress, and deletion."""
    # 1. Fetch existing roadmap
    res = client.get("/api/career-roadmap", headers=auth_headers)
    assert res.status_code == 200
    roadmap = res.json()
    assert "goals" in roadmap

    # 2. Create a new goal with 2 milestones
    goal_payload = {
        "title": "Machine Learning Portfolio",
        "category": "project",
        "target_date": "2026-12-01",
        "milestones": ["Train CNN model on CIFAR-10", "Deploy model to Hugging Face Spaces"]
    }
    create_res = client.post("/api/career-roadmap/goal", headers=auth_headers, json=goal_payload)
    assert create_res.status_code == 200
    goal_id = create_res.json()["goal_id"]

    # 3. Fetch roadmap to inspect milestone IDs
    res_after = client.get("/api/career-roadmap", headers=auth_headers)
    created_goal = next(g for g in res_after.json()["goals"] if g["id"] == goal_id)
    assert len(created_goal["milestones"]) == 2
    milestone_id = created_goal["milestones"][0]["id"]

    # 4. Toggle milestone completion
    patch_res = client.patch(f"/api/career-roadmap/milestone/{milestone_id}", headers=auth_headers)
    assert patch_res.status_code == 200
    assert patch_res.json()["milestone"]["completed"] is True

    # 5. Clean up goal
    del_res = client.delete(f"/api/career-roadmap/goal/{goal_id}", headers=auth_headers)
    assert del_res.status_code == 200

def test_campus_navigator_directory_search_and_filter():
    """Verify campus directory retrieval, category filtering, and search."""
    # All locations
    res = client.get("/api/navigator/directory")
    assert res.status_code == 200
    data = res.json()
    assert data["count"] >= 8

    # Filter by category
    res_lib = client.get("/api/navigator/directory?category=library")
    assert res_lib.status_code == 200
    for item in res_lib.json()["directory"]:
        assert item["category"] == "library"

    # Search keyword
    res_search = client.get("/api/navigator/directory?search=Computing")
    assert res_search.status_code == 200
    assert any("Computing" in item["name"] for item in res_search.json()["directory"])

def test_campus_notice_intelligence_and_bookmarks(auth_headers):
    """Verify announcements intelligence, priority filter, bookmarks, and read states."""
    # 1. Fetch notices
    res = client.get("/api/announcements/intelligence", headers=auth_headers)
    assert res.status_code == 200
    notices = res.json()["announcements"]
    assert len(notices) > 0
    test_notice = notices[0]

    # 2. Toggle save / bookmark
    save_res = client.post(f"/api/announcements/{test_notice['id']}/save", headers=auth_headers)
    assert save_res.status_code == 200
    is_saved = save_res.json()["is_saved"]

    # 3. Fetch only saved notices
    saved_res = client.get("/api/announcements/intelligence?only_saved=true", headers=auth_headers)
    assert saved_res.status_code == 200
    if is_saved:
        assert any(n["id"] == test_notice["id"] for n in saved_res.json()["announcements"])

    # 4. Mark notice as read
    read_res = client.post(f"/api/announcements/{test_notice['id']}/read", headers=auth_headers)
    assert read_res.status_code == 200
    assert read_res.json()["is_read"] is True

def test_recent_audit_activities(auth_headers):
    """Verify student audit activity logging and retrieval."""
    res = client.get("/api/activities/recent?limit=10", headers=auth_headers)
    assert res.status_code == 200
    activities = res.json()["activities"]
    assert isinstance(activities, list)
    assert len(activities) > 0
    act = activities[0]
    assert "description" in act
    assert "action_type" in act
    assert "created_at" in act
