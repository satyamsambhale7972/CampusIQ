"""
CampusIQ AI Assistant Tests
Tests question answering grounded in student context, fallback reasoning, and conversation clearing.
"""
import pytest
from starlette.testclient import TestClient

from main import app
from auth import create_access_token

client = TestClient(app)

def test_ai_copilot_grounded_queries():
    """Verify that AI Co-Pilot answers queries grounded in student's actual enrolled data."""
    token = create_access_token(user_id="student-ai-test", email="ai_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    # 1. Ask about attendance
    att_resp = client.post("/api/ai/chat", headers=headers, json={"message": "What is my attendance standing?"})
    assert att_resp.status_code == 200
    data = att_resp.json()
    assert "reply" in data
    assert len(data["reply"]) > 20
    assert "attendance" in data["reply"].lower()

    # 2. Ask about classroom locations
    loc_resp = client.post("/api/ai/chat", headers=headers, json={"message": "Where is Dr. Sharma's lecture?"})
    assert loc_resp.status_code == 200
    assert "Room A-204" in loc_resp.json()["reply"]

    # 3. Ask about campus facilities
    fac_resp = client.post("/api/ai/chat", headers=headers, json={"message": "Is Central Library open?"})
    assert fac_resp.status_code == 200
    assert "Central Library" in fac_resp.json()["reply"]

def test_ai_daily_brief_and_clear_history():
    """Verify personalized daily brief generation and chat history clearing."""
    token = create_access_token(user_id="student-brief-test", email="brief_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    # 1. Daily brief
    brief_resp = client.get("/api/ai/brief", headers=headers)
    assert brief_resp.status_code == 200
    cards = brief_resp.json()["cards"]
    assert len(cards) == 3
    for c in cards:
        assert "category" in c
        assert "title" in c
        assert "description" in c

    # 2. Clear history
    clear_resp = client.delete("/api/ai/history", headers=headers)
    assert clear_resp.status_code == 200
    assert "cleared" in clear_resp.json()["message"]

def test_ai_copilot_all_question_domains():
    """Verify that AI Co-Pilot provides real, authentic answers across multiple domains without runtime errors."""
    token = create_access_token(user_id="student-domain-test", email="domain_test@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    queries = [
        ("What is my current CGPA and results?", ["8.64", "results", "marksheet"]),
        ("Explain the Raft consensus algorithm and leader election.", ["raft", "leader election"]),
        ("What are Shift/Reduce conflicts in compiler design?", ["shift/reduce", "conflict"]),
        ("What are the hostel curfew hours and gate pass rules?", ["curfew", "hostel"]),
        ("Who do I contact in case of a medical emergency?", ["emergency", "ambulance"]),
        ("How can I prepare for campus placement interviews?", ["placement", "cgpa"]),
        ("Can you explain how backpropagation works in machine learning?", ["backpropagation", "loss"]),
        ("Any general random question about exams and syllabus", ["advisory", "semester 5"])
    ]

    for q, expected_words in queries:
        resp = client.post("/api/ai/chat", headers=headers, json={"message": q})
        assert resp.status_code == 200
        data = resp.json()
        assert "reply" in data and isinstance(data["reply"], str) and len(data["reply"]) > 20
        assert "response" in data and isinstance(data["response"], str)
        reply_lower = data["reply"].lower()
        for w in expected_words:
            assert w.lower() in reply_lower, f"Expected '{w}' in reply for query '{q}', got: {data['reply']}"
