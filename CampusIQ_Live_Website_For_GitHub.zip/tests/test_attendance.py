"""
CampusIQ Attendance Module Tests
Tests official attendance fetching, compliance checks, and real-time attendance logging.
"""
import pytest
from starlette.testclient import TestClient

from main import app
from auth import create_access_token

client = TestClient(app)

def test_get_and_log_attendance():
    token = create_access_token(user_id="student-att-test", email="att_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    # 1. Fetch initial attendance
    resp = client.get("/api/attendance", headers=headers)
    assert resp.status_code == 200
    data = resp.json()
    assert "overall_rate" in data
    assert "subjects" in data
    assert len(data["subjects"]) >= 4

    sub_id = data["subjects"][0]["subject_id"]

    # 2. Log attendance record for today
    log_resp = client.post(
        "/api/attendance/log",
        headers=headers,
        json={
            "subject_id": sub_id,
            "date": "2026-10-18",
            "status": "present",
            "notes": "Attended full lecture"
        }
    )
    assert log_resp.status_code == 200
    log_data = log_resp.json()
    assert log_data["success"] is True
    assert log_data["status"] == "present"

    # 3. Log absent record for a different date
    log_resp2 = client.post(
        "/api/attendance/log",
        headers=headers,
        json={
            "subject_id": sub_id,
            "date": "2026-10-19",
            "status": "absent",
            "notes": "Medical leave"
        }
    )
    assert log_resp2.status_code == 200
    assert log_resp2.json()["success"] is True
