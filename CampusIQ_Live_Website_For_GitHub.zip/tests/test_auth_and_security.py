"""
Authentication, Authorization, and Security Tests
Tests session verification, student data isolation, rate limiting, and security headers.
"""
import time
import pytest
from starlette.testclient import TestClient

from main import app, rate_limiter
from auth import create_access_token

client = TestClient(app)

def test_security_headers_present():
    """Verify that every HTTP response includes strict production security headers."""
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.headers.get("X-Content-Type-Options") == "nosniff"
    assert resp.headers.get("X-Frame-Options") == "DENY"
    assert resp.headers.get("X-XSS-Protection") == "1; mode=block"
    assert resp.headers.get("Referrer-Policy") == "strict-origin-when-cross-origin"
    assert "Content-Security-Policy" in resp.headers

def test_unauthorized_access_rejected():
    """Protected endpoints must reject requests lacking Authorization header with HTTP 401."""
    protected_endpoints = [
        ("GET", "/api/profile"),
        ("PUT", "/api/profile"),
        ("GET", "/api/attendance"),
        ("GET", "/api/academics/assignments"),
        ("POST", "/api/academics/assignments"),
        ("POST", "/api/attendance/log"),
        ("POST", "/api/ai/chat"),
        ("GET", "/api/ai/brief")
    ]
    for method, path in protected_endpoints:
        if method == "GET":
            resp = client.get(path)
        elif method == "PUT":
            resp = client.put(path, json={})
        elif method == "POST":
            resp = client.post(path, json={})
        assert resp.status_code == 401, f"{path} did not return 401 on unauthorized access: {resp.status_code}"

def test_invalid_and_expired_tokens_rejected():
    """Invalid signature or expired tokens must be rejected with HTTP 401."""
    # 1. Completely bogus token
    resp = client.get("/api/profile", headers={"Authorization": "Bearer not-a-valid-jwt"})
    assert resp.status_code == 401
    assert "Session invalid or expired" in resp.json()["detail"]

    # 2. Expired token
    expired_token = create_access_token(
        user_id="user-expired",
        email="expired@campusiq.edu",
        expires_in_seconds=-3600
    )
    resp = client.get("/api/profile", headers={"Authorization": f"Bearer {expired_token}"})
    assert resp.status_code == 401
    assert "Session expired" in resp.json()["detail"]

def test_student_data_isolation():
    """
    Authorization Isolation Test:
    Verify that Student A cannot modify or delete assignments created by Student B.
    """
    # Create tokens for two separate students
    token_a = create_access_token(user_id="student-alpha-101", email="alice@campusiq.edu")
    token_b = create_access_token(user_id="student-beta-202", email="bob@campusiq.edu")

    headers_a = {"Authorization": f"Bearer {token_a}"}
    headers_b = {"Authorization": f"Bearer {token_b}"}

    # Student A creates an assignment
    create_resp = client.post(
        "/api/academics/assignments",
        headers=headers_a,
        json={
            "title": "Alice Private Coursework",
            "due_date": "2026-10-30",
            "priority": "high"
        }
    )
    assert create_resp.status_code == 200
    assignment_id = create_resp.json()["assignment"]["id"]

    # Student B attempts to mark Student A's assignment as completed
    tamper_resp = client.patch(
        f"/api/academics/assignments/{assignment_id}/status",
        headers=headers_b,
        json={"status": "completed"}
    )
    assert tamper_resp.status_code == 404, "Student B was able to modify Student A assignment!"

    # Student B attempts to delete Student A's assignment
    delete_resp = client.delete(
        f"/api/academics/assignments/{assignment_id}",
        headers=headers_b
    )
    assert delete_resp.status_code == 404, "Student B was able to delete Student A assignment!"

    # Verify Student A's assignment is still pending and intact
    list_resp = client.get("/api/academics/assignments", headers=headers_a)
    assert list_resp.status_code == 200
    assignments = list_resp.json()["assignments"]
    alice_asgn = next((a for a in assignments if a["id"] == assignment_id), None)
    assert alice_asgn is not None
    assert alice_asgn["status"] == "pending"

def test_input_validation_and_rejection():
    """Verify server rejects malformed payloads and invalid inputs with HTTP 422."""
    token = create_access_token(user_id="student-test-val", email="val@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    # 1. Invalid assignment priority
    resp = client.post(
        "/api/academics/assignments",
        headers=headers,
        json={"title": "Test", "due_date": "2026-10-30", "priority": "extreme_invalid"}
    )
    assert resp.status_code == 422

    # 2. Empty title
    resp = client.post(
        "/api/academics/assignments",
        headers=headers,
        json={"title": "", "due_date": "2026-10-30"}
    )
    assert resp.status_code == 422

    # 3. Invalid profile payload
    resp = client.put(
        "/api/profile",
        headers=headers,
        json={"full_name": "A"}  # Too short (min 2 chars)
    )
    assert resp.status_code == 422
