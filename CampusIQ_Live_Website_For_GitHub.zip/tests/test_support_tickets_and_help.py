"""
Campus Help Centre and Support Ticketing Tests
Tests ticket creation, student isolation, conversation replies, and admin status updates.
"""
import pytest
from starlette.testclient import TestClient

from main import app
from auth import create_access_token

client = TestClient(app)

def test_faqs_retrieval():
    """Verify searchable FAQ retrieval."""
    resp = client.get("/api/help/faqs")
    assert resp.status_code == 200
    faqs = resp.json()["faqs"]
    assert len(faqs) >= 4
    assert any("attendance" in f["question"].lower() for f in faqs)

def test_support_ticket_lifecycle_and_isolation():
    """Verify ticket creation, isolation between students, reply threading, and admin management."""
    token_alice = create_access_token(user_id="alice-ticket-user", email="alice_tick@campusiq.edu")
    token_bob = create_access_token(user_id="bob-ticket-user", email="bob_tick@campusiq.edu")
    token_admin = create_access_token(user_id="admin-ticket-user", email="admin_tick@campusiq.edu", role="admin")

    headers_alice = {"Authorization": f"Bearer {token_alice}"}
    headers_bob = {"Authorization": f"Bearer {token_bob}"}
    headers_admin = {"Authorization": f"Bearer {token_admin}"}

    # 1. Alice creates a support ticket
    create_resp = client.post(
        "/api/help/tickets",
        headers=headers_alice,
        json={
            "subject": "Missing lab marks in CS302",
            "category": "results",
            "priority": "high",
            "message": "My practical evaluation score for Web Dev lab is not displaying in marksheet."
        }
    )
    assert create_resp.status_code == 200
    ticket_id = create_resp.json()["ticket"]["ticket_id"]
    ticket_num = create_resp.json()["ticket"]["ticket_number"]
    assert ticket_num.startswith("TICK-")

    # 2. Bob attempts to view Alice's ticket details (should be 403 Forbidden)
    bob_attempt = client.get(f"/api/help/tickets/{ticket_id}", headers=headers_bob)
    assert bob_attempt.status_code == 403, "Bob should not be able to view Alice ticket!"

    # 3. Alice views her own ticket
    alice_view = client.get(f"/api/help/tickets/{ticket_id}", headers=headers_alice)
    assert alice_view.status_code == 200
    ticket_data = alice_view.json()["ticket"]
    assert ticket_data["subject"] == "Missing lab marks in CS302"
    assert len(ticket_data["messages"]) == 1

    # 4. Admin views Alice's ticket and replies
    admin_view = client.get(f"/api/help/tickets/{ticket_id}", headers=headers_admin)
    assert admin_view.status_code == 200

    admin_reply = client.post(
        f"/api/help/tickets/{ticket_id}/reply",
        headers=headers_admin,
        json={"message": "We have contacted Prof. Mehta. The lab marksheet update is scheduled for tomorrow."}
    )
    assert admin_reply.status_code == 200
    assert admin_reply.json()["new_status"] == "awaiting_student"

    # 5. Admin updates status to resolved
    status_update = client.patch(
        f"/api/admin/tickets/{ticket_id}/status?status_val=resolved",
        headers=headers_admin
    )
    assert status_update.status_code == 200
    assert status_update.json()["status"] == "resolved"

    # 6. Verify Alice sees the admin response and resolved status
    alice_refresh = client.get(f"/api/help/tickets/{ticket_id}", headers=headers_alice)
    assert alice_refresh.status_code == 200
    updated_ticket = alice_refresh.json()["ticket"]
    assert updated_ticket["status"] == "resolved"
    assert len(updated_ticket["messages"]) == 2
