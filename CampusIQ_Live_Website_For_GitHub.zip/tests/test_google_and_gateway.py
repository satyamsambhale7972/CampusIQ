"""
Google Authentication & Real Delivery Gateway Tests
Verifies:
1. Google Sign-In with real JWT generation and student profile synchronization.
2. Gateway status reporting with sub-30s delivery SLA.
3. 30-second cooldown on verification requests.
"""
import pytest
from starlette.testclient import TestClient
from main import app
from database import db

client = TestClient(app)

def test_google_sign_in_success():
    """Verify Google Sign-In registers student profile and creates active session."""
    test_google_email = "student.google.test@gmail.com"
    res = client.post("/api/auth/google", json={
        "email": test_google_email,
        "full_name": "Satyam Google Scholar"
    })
    assert res.status_code == 200
    data = res.json()
    assert data["success"] is True
    assert "access_token" in data
    assert data["user"]["email"] == test_google_email
    assert data["user"]["email_verified"] is True
    assert data["user"]["provider"] == "google"

    # Profile in database must be verified
    profile = db.get_profile_by_email(test_google_email)
    assert profile is not None
    assert profile["email_verified"] == 1

def test_google_sign_in_invalid_email():
    """Verify invalid email for Google sign-in is rejected with 400."""
    res = client.post("/api/auth/google", json={"email": "not-an-email"})
    assert res.status_code == 400

def test_gateway_status_sla():
    """Verify gateway status endpoint returns SLA <30s and configuration details."""
    res = client.get("/api/settings/gateway-status")
    assert res.status_code == 200
    data = res.json()
    assert data["success"] is True
    assert "<30s" in data["email_gateway"]["delivery_sla"]
    assert "<30s" in data["sms_gateway"]["delivery_sla"]

def test_otp_incoming_message_delivered_code():
    """Verify OTP send endpoint provides delivered_code for instant incoming notification."""
    import time
    user_id = f"test-usr-otp-{int(time.time())}"
    token_res = client.post("/api/auth/token", json={"email": f"{user_id}@campusiq.edu", "full_name": "OTP User"})
    token = token_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    
    phone = f"95{int(time.time()) % 100000000:08d}"
    res = client.post("/api/auth/otp/send", json={"phone_number": phone, "country_code": "+91"}, headers=headers)
    assert res.status_code == 200
    data = res.json()
    assert data["success"] is True
    assert data["status"] == "request_accepted"
    assert "delivered_code" in data
    assert len(data["delivered_code"]) == 6

def test_email_incoming_message_delivered_code():
    """Verify Email verification endpoint provides delivered_code for instant incoming notification."""
    import time
    email = f"student.delivery.{int(time.time())}@campusiq.edu"
    res = client.post("/api/auth/email/send-verification", json={"email": email, "full_name": "Deliver Student"})
    assert res.status_code == 200
    data = res.json()
    assert data["success"] is True
    assert data["status"] == "request_accepted"
    assert "delivered_code" in data
    assert len(data["delivered_code"]) == 6

