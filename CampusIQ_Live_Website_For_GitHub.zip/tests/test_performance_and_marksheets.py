"""
Academic Performance, Digital Marksheets, and Results Tests
"""
import pytest
from starlette.testclient import TestClient

from main import app
from auth import create_access_token

client = TestClient(app)

def test_performance_and_results_retrieval():
    """Verify performance metrics, SGPA/CGPA calculations, and digital marksheet records."""
    token = create_access_token(user_id="student-marks-test", email="marks_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    # 1. Get Performance Summary
    perf_resp = client.get("/api/academics/performance", headers=headers)
    assert perf_resp.status_code == 200
    perf = perf_resp.json()

    assert perf["student_name"] == "Marks Student"
    assert "sgpa" in perf
    assert "cgpa" in perf
    assert perf["sgpa"] > 0
    assert perf["cgpa"] > 0
    assert "results" in perf
    assert len(perf["results"]) >= 4, "Baseline curriculum courses should have results"
    assert perf["verification_ref"].startswith("REF-")

    # 2. Get Semester 5 Marksheet Details
    res_resp = client.get("/api/academics/results?semester=Semester%205", headers=headers)
    assert res_resp.status_code == 200
    sheet = res_resp.json()
    assert sheet["semester"] == "Semester 5"
    assert sheet["total_credits"] > 0

    first_sub = sheet["results"][0]
    assert "internal_marks" in first_sub
    assert "external_marks" in first_sub
    assert "total_marks" in first_sub
    assert first_sub["total_marks"] == first_sub["internal_marks"] + first_sub["external_marks"]
    assert first_sub["letter_grade"] in ("O", "A+", "A", "B+", "B", "C", "P", "F")

def test_admin_result_publishing_and_rbac():
    """
    Role-Based Access Control:
    Verify that an administrator can publish/update official results,
    while a regular student is strictly forbidden (HTTP 403).
    """
    student_token = create_access_token(user_id="student-non-admin", email="regular@campusiq.edu", role="student")
    admin_token = create_access_token(user_id="admin-user-01", email="controller@campusiq.edu", role="admin")

    student_headers = {"Authorization": f"Bearer {student_token}"}
    admin_headers = {"Authorization": f"Bearer {admin_token}"}

    payload = {
        "student_id": "student-marks-test",
        "subject_id": "sub-1",
        "semester": "Semester 5",
        "internal_marks": 39.0,
        "external_marks": 58.0,
        "letter_grade": "O",
        "grade_point": 10.0,
        "pass_fail": "PASS"
    }

    # Student attempt should fail with 403 Forbidden
    student_attempt = client.post("/api/admin/results/publish", headers=student_headers, json=payload)
    assert student_attempt.status_code == 403

    # Admin attempt should succeed
    admin_attempt = client.post("/api/admin/results/publish", headers=admin_headers, json=payload)
    assert admin_attempt.status_code == 200
    assert "officially published" in admin_attempt.json()["message"]
