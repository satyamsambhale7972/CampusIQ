"""
Mobile OTP Verification and Profile Management Tests
"""
import pytest
from starlette.testclient import TestClient

from main import app
from auth import create_access_token
from database import db

client = TestClient(app)

def test_mobile_otp_lifecycle():
    """Verify full mobile OTP flow: database record creation, cooldown enforcement, incorrect OTP rejection, and successful verification."""
    user_id = "student-otp-test"
    db.get_or_create_profile(user_id=user_id, email="otp_student@campusiq.edu")
    token = create_access_token(user_id=user_id, email="otp_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}
    import time
    phone = f"987{int(time.time()) % 10000000:07d}"
    country = "+91"


    # 1. Request OTP via database engine
    otp_record = db.request_phone_otp(user_id=user_id, phone_number=phone, country_code=country)
    assert otp_record["success"] is True
    assert otp_record["status"] == "request_accepted"
    raw_otp = otp_record["raw_otp"]
    assert len(raw_otp) == 6

    # 2. Attempt immediate second OTP (cooldown check via API)
    cooldown_resp = client.post("/api/auth/otp/send", headers=headers, json={"phone_number": phone, "country_code": country})
    assert cooldown_resp.status_code == 429
    assert cooldown_resp.json()["detail"]["cooldown"] is True

    # 3. Verify with wrong code via API
    bad_verify = client.post("/api/auth/otp/verify", headers=headers, json={"phone_number": phone, "country_code": country, "otp": "000000"})
    assert bad_verify.status_code == 400
    assert "Incorrect" in bad_verify.json()["detail"]["message"]

    # 4. Verify with authentic code via API
    good_verify = client.post("/api/auth/otp/verify", headers=headers, json={"phone_number": phone, "country_code": country, "otp": raw_otp})
    assert good_verify.status_code == 200
    assert good_verify.json()["status"] == "verified"

    # 5. Check profile reflects verified phone
    prof_resp = client.get("/api/profile", headers=headers)
    assert prof_resp.status_code == 200
    prof = prof_resp.json()
    assert prof["phone_number"] == phone
    assert prof["phone_verified"] == 1


def test_profile_update_and_photo():
    """Test updating student name, department, semester, and photo."""
    token = create_access_token(user_id="student-profile-test", email="profile_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    update_resp = client.put(
        "/api/profile",
        headers=headers,
        json={
            "full_name": "Satyam Sambhale",
            "department": "Artificial Intelligence & Data Science",
            "year_semester": "Year 3, Semester 6",
            "branch": "AI & DS"
        }
    )
    assert update_resp.status_code == 200
    profile = update_resp.json()["profile"]
    assert profile["full_name"] == "Satyam Sambhale"
    assert profile["department"] == "Artificial Intelligence & Data Science"

    # Photo update
    photo_resp = client.post(
        "/api/profile/photo",
        headers=headers,
        json={"avatar_url": "https://campusiq.internal/avatars/satyam.png"}
    )
    assert photo_resp.status_code == 200

def test_student_account_purge():
    """Verify permanent student account deletion."""
    token = create_access_token(user_id="student-purge-test", email="purge_student@campusiq.edu")
    headers = {"Authorization": f"Bearer {token}"}

    del_resp = client.delete("/api/profile/account", headers=headers)
    assert del_resp.status_code == 200
    assert "purged" in del_resp.json()["message"].lower()

    # Re-accessing with that token should fail or create empty profile
    check = client.get("/api/profile", headers=headers)
    # The profile row was deleted; auto-create recreates empty
    assert check.status_code == 200
    assert check.json()["full_name"] != "Satyam Sambhale"
