"""
CampusIQ Load Testing and Concurrency Evaluation Framework
Measures throughput (requests/sec), latency percentiles (p50, p90, p95, p99),
and error rates under increasing concurrency levels.
"""
import asyncio
import time
import os
import sys
from typing import List, Dict, Any
import httpx

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from main import app, rate_limiter

# Temporarily elevate rate limiter for benchmark
rate_limiter.limit = 1000000

BASE_URL = "http://127.0.0.1:8000"

ENDPOINTS = [
    "/api/health",
    "/api/academics/subjects",
    "/api/facilities",
    "/api/announcements",
    "/api/navigator/directory",
    "/api/announcements/intelligence",
    "/api/help/faqs"
]

async def worker(client: httpx.AsyncClient, queue: asyncio.Queue, results: List[float], errors: List[str]):
    while not queue.empty():
        path = await queue.get()
        t0 = time.perf_counter()
        try:
            resp = await client.get(path)
            latency_ms = (time.perf_counter() - t0) * 1000
            if resp.status_code == 200:
                results.append(latency_ms)
            else:
                errors.append(f"HTTP {resp.status_code} on {path}")
        except Exception as e:
            errors.append(str(e))
        finally:
            queue.task_done()

async def run_load_tier(concurrency: int, total_requests: int, use_asgi: bool) -> Dict[str, Any]:
    queue = asyncio.Queue()
    for i in range(total_requests):
        path = ENDPOINTS[i % len(ENDPOINTS)]
        await queue.put(path)

    results: List[float] = []
    errors: List[str] = []

    limits = httpx.Limits(max_keepalive_connections=concurrency, max_connections=concurrency * 2)
    timeout = httpx.Timeout(15.0)

    if use_asgi:
        transport = httpx.ASGITransport(app=app)
        client = httpx.AsyncClient(transport=transport, base_url="http://testserver", limits=limits, timeout=timeout)
    else:
        client = httpx.AsyncClient(base_url=BASE_URL, limits=limits, timeout=timeout)

    t_start = time.perf_counter()
    async with client:
        workers = [
            asyncio.create_task(worker(client, queue, results, errors))
            for _ in range(concurrency)
        ]
        await queue.join()
        for w in workers:
            w.cancel()

    duration = time.perf_counter() - t_start
    rps = round(len(results) / duration, 2) if duration > 0 else 0

    sorted_latencies = sorted(results) if results else [0]
    n = len(sorted_latencies)

    p50 = sorted_latencies[int(n * 0.50)] if n else 0
    p90 = sorted_latencies[int(n * 0.90)] if n else 0
    p95 = sorted_latencies[int(n * 0.95)] if n else 0
    p99 = sorted_latencies[int(n * 0.99)] if n else 0
    min_lat = round(sorted_latencies[0], 2) if n else 0
    max_lat = round(sorted_latencies[-1], 2) if n else 0

    error_rate = round((len(errors) / total_requests) * 100, 2) if total_requests > 0 else 0

    return {
        "concurrency": concurrency,
        "total_requests": total_requests,
        "successful_requests": len(results),
        "failed_requests": len(errors),
        "error_rate_pct": error_rate,
        "duration_seconds": round(duration, 3),
        "requests_per_second": rps,
        "min_latency_ms": min_lat,
        "p50_latency_ms": round(p50, 2),
        "p90_latency_ms": round(p90, 2),
        "p95_latency_ms": round(p95, 2),
        "p99_latency_ms": round(p99, 2),
        "max_latency_ms": max_lat
    }

async def main():
    print("=" * 65)
    print(" CampusIQ Concurrency & Load Testing Benchmark")
    print("=" * 65)

    # Detect live server or fallback to ASGI transport
    use_asgi = True
    try:
        async with httpx.AsyncClient(timeout=1.0) as test_c:
            r = await test_c.get(f"{BASE_URL}/api/health")
            if r.status_code == 200:
                use_asgi = False
                print("[Mode] Testing against live server at http://127.0.0.1:8000")
    except Exception:
        pass

    if use_asgi:
        print("[Mode] In-process ASGI transport benchmark (Direct kernel execution)")

    tiers = [
        (10, 100),
        (25, 250),
        (50, 500),
        (100, 1000)
    ]

    all_results = []
    for conc, reqs in tiers:
        print(f"\n[Benchmarking Tier] Concurrency: {conc:3d} workers | Total Requests: {reqs:4d}...")
        res = await run_load_tier(conc, reqs, use_asgi)
        all_results.append(res)
        print(f" -> Duration: {res['duration_seconds']}s | RPS: {res['requests_per_second']} req/s | Error Rate: {res['error_rate_pct']}%")
        print(f" -> Latencies: Min={res['min_latency_ms']}ms | p50={res['p50_latency_ms']}ms | p95={res['p95_latency_ms']}ms | p99={res['p99_latency_ms']}ms")

    print("\n" + "=" * 65)
    print(" Benchmark Summary Table")
    print("=" * 65)
    print(f"{'Concurrency':<12} {'Total Req':<10} {'RPS':<10} {'p50 (ms)':<10} {'p95 (ms)':<10} {'p99 (ms)':<10} {'Error %':<8}")
    print("-" * 65)
    for r in all_results:
        print(f"{r['concurrency']:<12} {r['total_requests']:<10} {r['requests_per_second']:<10} {r['p50_latency_ms']:<10} {r['p95_latency_ms']:<10} {r['p99_latency_ms']:<10} {r['error_rate_pct']:<8}")
    print("=" * 65)

if __name__ == "__main__":
    asyncio.run(main())
